package com.example.jellick_project_2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class SMSActivity extends AppCompatActivity {

    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Set up permission request
        requestPermissionLauncher =
                registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (isGranted) {
                        sendSMS();
                    } else {
                        Toast.makeText(this, "SMS notifications denied", Toast.LENGTH_SHORT).show();
                        openDataActivity();
                    }
                });

        checkSMSPermission();
    }

    private void checkSMSPermission() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Permission already granted
            sendSMS();
        } else {
            // Request permission
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void sendSMS() {
        try {
            String phoneNumber = "1234567890"; // Replace with target number
            String message = "Welcome to the app!";

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error sending SMS", Toast.LENGTH_SHORT).show();
        } finally {
            openDataActivity();
        }
    }

    private void openDataActivity() {
        String username = getIntent().getStringExtra("username");
        if (username == null) username = "";
        startActivity(new Intent(SMSActivity.this, DataActivity.class)
                .putExtra("username", username));
        finish();
    }
}