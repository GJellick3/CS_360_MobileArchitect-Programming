package com.example.jellick_project_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etUsername, etPassword;
    Button btnLogin, btnCreateAccount;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        dbHelper = new DatabaseHelper(this);

        // --- LOGIN BUTTON ---
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean valid = dbHelper.checkuser(username, password);

                if (valid) {
                    Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                    SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
                    String smsKey = username + "_smsRequested";
                    boolean smsRequested = prefs.getBoolean(smsKey, false);

                    if (!smsRequested) {
                        // --- Start SMSActivity first ---
                        Intent smsIntent = new Intent(LoginActivity.this, SMSActivity.class);
                        smsIntent.putExtra("username", username);
                        startActivity(smsIntent);

                        prefs.edit().putBoolean(smsKey, true).apply();
                        finish(); // finish login to prevent going back
                    } else {
                        // --- Open DataActivity directly ---
                        Intent dataIntent = new Intent(LoginActivity.this, DataActivity.class);
                        dataIntent.putExtra("username", username);
                        startActivity(dataIntent);
                        finish();
                    }

                } else {
                    Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // --- CREATE ACCOUNT BUTTON ---
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean created = dbHelper.insertUser(username, password);
                if (created) {
                    Toast.makeText(LoginActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LoginActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}