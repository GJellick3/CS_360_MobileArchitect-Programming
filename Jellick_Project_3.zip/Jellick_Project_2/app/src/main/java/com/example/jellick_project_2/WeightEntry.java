package com.example.jellick_project_2;

public class WeightEntry {
    int id;
    double weight;
    String date;

    public WeightEntry(int id, double weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public double getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }
}
