package com.example.jellick_project_2;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    EditText etNewWeight, etNewDate;
    Button btnAdd;
    RecyclerView rvDataGrid;

    DatabaseHelper dbHelper;
    WeightAdapter adapter;
    ArrayList<WeightEntry> weightList;
    String currentUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // --- Initialize views ---
        etNewWeight = findViewById(R.id.etNewWeight);
        etNewDate = findViewById(R.id.etNewDate);
        btnAdd = findViewById(R.id.btnAddWeight);
        rvDataGrid = findViewById(R.id.rvDataGrid);

        dbHelper = new DatabaseHelper(this);
        weightList = new ArrayList<>();

        // --- Get logged-in username from Intent ---
        currentUsername = getIntent().getStringExtra("username");
        if (currentUsername == null) {
            Toast.makeText(this, "Error: No user found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // --- Set up RecyclerView ---
        rvDataGrid.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightAdapter(weightList);
        rvDataGrid.setAdapter(adapter);

        // --- Load existing weights for this user ---
        loadWeights();

        // --- Add new weight entry ---
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightStr = etNewWeight.getText().toString().trim();
                String dateStr = etNewDate.getText().toString().trim();

                if (weightStr.isEmpty() || dateStr.isEmpty()) {
                    Toast.makeText(DataActivity.this, "Please enter both fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                double weight;
                try {
                    weight = Double.parseDouble(weightStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(DataActivity.this, "Invalid weight", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Insert weight for this specific user
                boolean inserted = dbHelper.insertWeight(currentUsername, weight, dateStr);

                if (inserted) {
                    Toast.makeText(DataActivity.this, "Added Successfully", Toast.LENGTH_SHORT).show();
                    etNewWeight.setText("");
                    etNewDate.setText("");
                    loadWeights(); // Refresh list
                } else {
                    Toast.makeText(DataActivity.this, "Error adding data", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // --- Load weights for current user only ---
    private void loadWeights() {
        weightList.clear();

        Cursor cursor = dbHelper.getWeightsForUser(currentUsername);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));

                weightList.add(new WeightEntry(id, weight, date));
            } while (cursor.moveToNext());
            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }
}